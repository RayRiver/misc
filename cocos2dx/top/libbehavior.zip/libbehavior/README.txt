The examples require the Visual Studio 2008 Runtime, available here:
http://www.microsoft.com/downloads/details.aspx?familyid=A5C84275-3B97-4AB7-A40D-3802B2AF5FC2&displaylang=en

Please also make sure your graphics drivers are up to date. Very old graphics drivers may prevent the examples from running.

The BehaviorTree source has no special dependencies.

The BehaviorTree tests rely on Boost Test Library 1.38.

The Example source relies on clanlib 2.0.0 and the DirectX SDK.