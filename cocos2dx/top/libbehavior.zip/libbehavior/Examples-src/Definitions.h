#define ABSOLUTE_MOVEMENT
//#define RELATIVE_MOVEMENT
//#define PHYSICS
#define NOPHYSICS
#define DEBUG