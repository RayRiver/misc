#ifndef SOUNDMANAGER_H_
#define SOUNDMANAGER_H_

namespace SL
{
	class SoundManager
	{

	};
}
#endif