//Renderer that targets OpenGL
//Will be much faster and more capable, but will require more functionality in worldState to reach full potential

