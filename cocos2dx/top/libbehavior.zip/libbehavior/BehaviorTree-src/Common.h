#ifndef COMMON_H_
#define COMMON_H_
namespace BehaviorTree
	{
		class NoClass{};
	}

#endif
